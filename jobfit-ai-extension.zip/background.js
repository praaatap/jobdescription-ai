chrome.runtime.onInstalled.addListener(()=>{chrome.storage.local.set({jobHistory:[],cachedResume:null}),chrome.contextMenus.create({id:"analyzeJobPage",title:"Analyze with JobFit AI",contexts:["page"]})});chrome.contextMenus.onClicked.addListener(async(e,n)=>{e.menuItemId==="analyzeJobPage"&&n?.id&&chrome.action.openPopup()});function l(e,n){return`You are an expert ATS and career coach. Analyze this resume against the job description.

Return ONLY valid JSON:
{
  "matchScore": <0-100>,
  "recommendation": "<strongly_apply|apply|consider|not_recommended>",
  "recommendationReasons": ["reason1", "reason2", "reason3"],
  "summary": "<one sentence assessment>",
  "strengths": ["strength1", "strength2", "strength3"],
  "improvements": ["improvement1", "improvement2", "improvement3"],
  "missingKeywords": ["keyword1", "keyword2", "keyword3"],
  "atsWarnings": ["warning1", "warning2"],
  "interviewTips": ["tip1", "tip2", "tip3"]
}

Guidelines:
- strongly_apply (85-100%): Excellent match
- apply (70-84%): Good match
- consider (50-69%): Moderate match
- not_recommended (0-49%): Poor match

---RESUME---
${e.slice(0,8e3)}

---JOB DESCRIPTION---
${n.slice(0,8e3)}`}function m(e,n,t,r,o,s){return`Write a ${o} cover letter for ${t} at ${r}. Length: ${{short:"150-200",medium:"250-350",long:"400-500"}[s]||"250-350"} words.

Resume: ${e.slice(0,4e3)}
Job: ${n.slice(0,4e3)}

Write the letter directly, no placeholders.`}chrome.runtime.onMessage.addListener((e,n,t)=>e.type==="analyze"?(d(e,t),!0):e.type==="generateCoverLetter"?(u(e.request,t),!0):e.type==="updateJobStatus"?(p(e.jobId,e.status,t),!0):!1);async function d(e,n){try{const{geminiKey:t}=await chrome.storage.sync.get(["geminiKey"]);if(!t){n({success:!1,error:"Add API key in Settings"});return}const r=l(e.resumeText,e.websiteText),o=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${t}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:r}]}],generationConfig:{response_mime_type:"application/json",temperature:.7}})});if(!o.ok)throw new Error((await o.json()).error?.message||"API Error");const a=(await o.json()).candidates[0].content.parts[0].text,c=JSON.parse(a),{jobHistory:i=[]}=await chrome.storage.local.get(["jobHistory"]);i.unshift({id:Date.now(),jobTitle:e.jobTitle||"Unknown",company:e.company||"Unknown",matchScore:c.matchScore,analyzedAt:Date.now(),url:e.url||"",status:"pending",fullAnalysis:c}),i.length>30&&(i.length=30),await chrome.storage.local.set({jobHistory:i}),n({success:!0,reply:a})}catch(t){n({success:!1,error:t instanceof Error?t.message:"Error"})}}async function u(e,n){try{const{geminiKey:t}=await chrome.storage.sync.get(["geminiKey"]);if(!t){n({success:!1,error:"Add API key"});return}const r=m(e.resumeText,e.jobDescription,e.jobTitle,e.company,e.tone||"professional",e.length||"medium"),o=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${t}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:r}]}],generationConfig:{temperature:.8}})});if(!o.ok)throw new Error("API Error");const a=(await o.json()).candidates[0].content.parts[0].text;n({success:!0,coverLetter:{content:a,wordCount:a.split(/\s+/).length,generatedAt:Date.now()}})}catch(t){n({success:!1,error:t instanceof Error?t.message:"Error"})}}async function p(e,n,t){const{jobHistory:r=[]}=await chrome.storage.local.get(["jobHistory"]),o=r.find(s=>s.id===e);o&&(o.status=n,await chrome.storage.local.set({jobHistory:r})),t({success:!!o})}
